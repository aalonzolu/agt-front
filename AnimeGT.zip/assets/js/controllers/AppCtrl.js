﻿app.controller('AppCtrl', function ($scope, $timeout) {
    // Form data for the login modal
    $scope.loginData = {};


});
